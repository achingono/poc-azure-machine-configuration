<#
    This file is intentionally left empty. It is must be left here for the module
    manifest to refe to. It is recreated during the build process.
#>
